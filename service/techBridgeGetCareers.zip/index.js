'use strict';

var AWS = require("aws-sdk");
var doc = require('dynamodb-doc');


/**
 * Provide an event that contains the following keys:
 *
 *   - operation: one of the operations in the switch statement below
 *   - tableName: required for operations that interact with DynamoDB
 *   - payload: a parameter to pass to the operation being performed
 */
exports.handler = function(event, context, callback) {

    var interest;
    if (event.params && event.params.querystring) {
        interest = event.params.querystring.interest;
    }
    
    interest = interest || "DUMMY-INTEREST";
    
    var awsClient = new AWS.DynamoDB();
    var docClient = new doc.DynamoDB(awsClient);
    
    //var interest = "Acting";
    var params = {};
    params.TableName = "Career";
    params.Key = {interest : interest}

    docClient.getItem(params, function(err, data) {
        if (err) {
            console.log (err)
            callback(err);
        } else {
            callback(null, data.Item);
        }
    });
}