'use strict';

var AWS = require("aws-sdk");
var doc = require('dynamodb-doc');
//var dynamo = new doc.DynamoDB();

/**
 * Provide an event that contains the following keys:
 *
 *   - operation: one of the operations in the switch statement below
 *   - tableName: required for operations that interact with DynamoDB
 *   - payload: a parameter to pass to the operation being performed
 */
exports.handler = function(event, context, callback) {
    
    var awsClient = new AWS.DynamoDB();
    var docClient = new doc.DynamoDB(awsClient);
    
    var params = {};
    params.TableName = "Interest";
    //params.Key = {col1 : "test"}

    docClient.scan(params, function(err, data) {
        if (err) {
            console.log (err)
            callback(err);
        } else {
            callback(null, data.Items);
        }
    });
    
}